package com.shine.bookshop.test;

import com.shine.bookshop.util.DateUtil;
import com.shine.bookshop.util.RanUtil;

/** 
* @version 创建时间：2017年10月22日 下午10:03:19 
*/
public class Test {
	
	public static void main(String[] args) {
		System.out.println(DateUtil.show());

	}

}
