package com.shine.bookshop.test;
/** 
* @version 创建时间：2017年10月24日 下午4:04:41 
*/
public class Test2 {

	public static void main(String[] args) {
		// TODO 自动生成的方法存根
		System.out.println((int)(Math.random()*6));
	}

}
